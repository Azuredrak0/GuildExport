Vanilla wow api is fairly limited when it comes to what you can write,
so best i can do is write it to a variable in the WTF folder


Example location on a windows system


    C:\Users\$Owner\turtle_client_116\WTF\Account\$ACCOUNT\SavedVariables\RaidMemberExport.lua

Results found in that file
```lua
RaidMemberExportDB = "
Hobbitpally
Hobbitkaz
Hobbitt
"
```


When you are ready to store the variable you can type

    /exportraid

And when you're ready for that to be written to the SaveVariables File in the WTF Folder you can then reload your client

If you have pfui you can reload your client with either of these commands.

    /reload or /rl
